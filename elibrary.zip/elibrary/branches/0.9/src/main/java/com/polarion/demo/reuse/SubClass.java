package com.polarion.demo.reuse;

import com.polarion.demo.Library;

public class SubClass extends Library {

    public SubClass() {
        super();
    }

}
